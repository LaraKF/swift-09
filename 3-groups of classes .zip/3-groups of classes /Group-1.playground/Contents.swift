import UIKit

class Person {
    
    fileprivate var name: String
    private var age: Int
    
    
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
}


class Student: Person {
    
    public var major: String
    var numCourses: Int
    var studentGrades = ["Lara": 100, "Sara": 90, "Jojo": 95]
    
    init(major: String, numCourses: Int) {
        self.major = major
        self.numCourses = numCourses
        super.init(name: "Lara", age: 19)
    }

}

class Employee: Person {
    
    var salaries: Float
    var numEmployees: Int
    
    init(salaries: Float, numEmployees: Int) {
        self.salaries = salaries
        self.numEmployees = numEmployees
        super.init(name: "Jojo", age: 24)
    }
}


class Graduate: Student {
    
    let gYear: Int
    var gpa: Double
    
    init(gYear: Int, gpa: Double) {
        self.gYear = gYear
        self.gpa = gpa
        super.init(major: "Software Engineering", numCourses: 36)
    }

}

class UnderGradute: Student {
    
    let studentId: Int
    
    enum Courses {
    case swift
    case java
    case math
    case chemistry
    }
    
    var newCourses: Courses
    
    init(studentId: Int, newCourses: Courses) {
        self.studentId = studentId
        self.newCourses = newCourses
        super.init(major: "Computer Science", numCourses: 19)
    }
    
}

protocol Staff {
    
    var phoneNo: Int { get set }
    var email: String { get set }

}

class Professional: Staff {

    var phoneNo: Int = 0
    var email: String = ""

}

class Hourly: Staff {
    
    var phoneNo: Int = 0
    var email: String = ""
    var swiftKeywords = ["break", "case", "continue", "default", "do", "else", "fallthrough", "for", "if", "in", "return", "switch", "where", "while"]
    
}

class Faculty: Employee{
    
    var officeLocation: String
    let id: Int
    
    init(officeLocation: String, id: Int){
        self.officeLocation = officeLocation
        self.id = id
        super.init(salaries: 17500.88, numEmployees: 35)
    }
}

class Masters: Graduate {
    
    let masterId: Int
    var masterMajor: String
    
    init(masterId: Int, masterMajor: String) {
        self.masterId = masterId
        self.masterMajor = masterMajor
        super.init(gYear: 2022, gpa: 4.11)
    }
}

class phD: Graduate {
    
    let phDid: Int
    var phDmajor: String
    
    init(phDid: Int, phDmajor: String) {
        self.phDid = phDid
        self.phDmajor = phDmajor
        super.init(gYear: 2021, gpa: 4.5)
    }
}

struct Time {
    var time: Int
}

class NonDegree: Graduate {
    
    var programName: String
    var duration: Time
    
    init(programName: String, duration: Time) {
        self.programName = programName
        self.duration = duration
        super.init(gYear: 2023, gpa: 4.33)
    }
}
