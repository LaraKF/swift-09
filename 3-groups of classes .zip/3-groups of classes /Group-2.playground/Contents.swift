import UIKit

class Food {
    
    private var type: String
    fileprivate var source: String

    
    init(type: String, source: String) {
        self.type = type
        self.source = source
    }
}

class Fruit: Food {
    
    public var flavour: String
    var color: String
    var FruitCalories = ["Banana": 100, "Orange": 35, "Lemon": 15, "Apple": 13]
    
    init(flavour: String, color: String){
        self.flavour = flavour
        self.color = color
        super.init(type:"Fruit", source: "Vegetarian")
    }
}

protocol Vegetable {
    
    var calories: Double { get set }
    var name: String { get set }
    
}

class Meats: Food {
    
    var weight: Float
    var meatColor: String

    init(weight: Float, meatColor: String){
        self.weight = weight
        self.meatColor = meatColor
        super.init(type: "Meat", source: "Animal")
    }
}


class Lemon: Fruit {
    
    var numOfLemon: Int
    var lemonShape: String

    init(numOfLemon: Int, lemonShape: String){
        self.numOfLemon = numOfLemon
        self.lemonShape = lemonShape
        super.init(flavour: "Sour", color: "Yellow")
    }
}

class Apple: Fruit {
    
    var numOfApples: Int
    var appleShape: String
    
    enum ApplesTypes {
        case Green
        case Yellow
        case Red
    }
    
    var newApplesTypes: ApplesTypes

    init(numOfApples: Int, appleShape: String, newApplesTypes: ApplesTypes){
        self.numOfApples = numOfApples
        self.appleShape = appleShape
        self.newApplesTypes = newApplesTypes
        super.init(flavour: "Sweet", color: "Red")
    }
}

class Potato: Vegetable {
    var calories: Double = 0.0
    var name: String = ""
    var swiftKeywords = ["break", "case", "continue", "default", "do", "else", "fallthrough", "for", "if", "in", "return", "switch", "where", "while"]
}

class Carrot: Vegetable {
    var calories: Double = 0.0
    var name: String = ""
    
}

struct ExDate {
    var exDate: Int
}

class Chicken: Meats {
    var pDate: Int
    var exDate: ExDate
    
    init(pDate: Int, exDate: ExDate){
        self.pDate = pDate
        self.exDate = exDate
        super.init(weight: 2.5, meatColor: "White")
    }
}

class Beef: Meats {
    var withBone: Bool
    var withFat: Bool
    
    init(withBone: Bool, withFat: Bool){
        self.withBone = withBone
        self.withFat = withFat
        super.init(weight: 4.8, meatColor: "Red")
    }
}

class Fish: Meats {
    var salmon: Bool
    var grouper: Bool
    
    init(salmon: Bool, grouper: Bool){
        self.salmon = salmon
        self.grouper = grouper
        super.init(weight: 6.1, meatColor: "White")
    }
}
