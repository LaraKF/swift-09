import UIKit

class Vehicle {
    
    private var cost: Double
    fileprivate var weight: Float
    
    init(cost: Double, weight: Float){
        self.cost = cost
        self.weight = weight
    }
}

class LandVehicle: Vehicle {
    
    public var speed: Float
    var power: Float
    var price = ["Lexus es": 150000, "Range Rover": 344825.20]
    
    init(speed: Float, power: Float){
        self.speed = speed
        self.power = power
        super.init(cost: 259742, weight: 1740)
    }
}

class WaterVehicle: Vehicle {
    var sellingYear: Int
    var manufacturar: Int
    
    enum years {
        case Y2019
        case Y2020
        case Y2021
        case Y2022
    }
    
    var year: years
    
    init(sellingYear: Int, manufacturar: Int, year: years){
        self.sellingYear = sellingYear
        self.manufacturar = manufacturar
        self.year = year
        super.init(cost: 157420.20, weight: 1100)
    }
}

class AirVehicle: Vehicle {
    var hight: Float
    var capacity: Float
    
    init(hight: Float, capacity: Float){
        self.hight = hight
        self.capacity = capacity
        super.init(cost: 333768.30, weight: 41000)
    }
}

class FourWheels: LandVehicle {
    var engineSize: Double
    var fuel: Double
    
    init(engineSize: Double, fuel:Double){
        self.engineSize = engineSize
        self.fuel = fuel
        super.init(speed: 240, power: 350)
    }
}

protocol TwoWheels {
    
    var topSpeed: Double { get set }
    var distance: Double { get set }
    
}

struct Gearbox {
    var gearbox: Double
}

class Car: FourWheels {
    var bodyType: String
    var gearbox: Gearbox
    
    init(bodyType: String, gearbox: Gearbox){
        self.bodyType = bodyType
        self.gearbox = gearbox
        super.init(engineSize: 2487, fuel: 15.9)
    }
}


class Motorcycle: TwoWheels {
    
    var topSpeed: Double = 0.0
    var distance: Double = 0.0
    var swiftKeywords = ["break", "case", "continue", "default", "do", "else", "fallthrough", "for", "if", "in", "return", "switch", "where", "while"]
    
}

class Bicycle: TwoWheels {
    
    var topSpeed: Double = 0.0
    var distance: Double = 0.0
    
}

class Powered: AirVehicle {
    var environmentalCS: String
    var flightCS: String
    
    init(environmentalCS: String, flightCS: String){
        self.environmentalCS = environmentalCS
        self.flightCS = flightCS
        super.init(hight: 34000, capacity: 767)
    }
}

class Unpowered: AirVehicle {
    var direction: String
    var wings: Int
    
    init(direction: String, wings: Int){
        self.direction = direction
        self.wings = wings
        super.init(hight: 27000, capacity: 2)
    }
}
